num=10
if num:
    print("Wow")