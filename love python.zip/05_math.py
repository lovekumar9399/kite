x = 5
y = 3.5
z = "Hello"
print(x + y, z)