my_list = [10,20,1,30,40,50,20]
print(len(my_list))
print(max(my_list))
print(min(my_list))