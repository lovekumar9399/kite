a=10;b=25
print(a+b);print(a-b);print(a*b);print(a/b)