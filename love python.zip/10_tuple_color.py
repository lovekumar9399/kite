color = ("yellow","red","blue","green")
print(color[3])