import math
print(math.pow(2,3))