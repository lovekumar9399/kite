for i in range(2):
    print("Nutan")