num=10
if num<5:
    print("Good")
elif num<10:
    print("Nice")
else:
    print("Wow")