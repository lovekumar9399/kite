l=[1,2,3]
it=iter(l)
print(next(it));print(next(it));print(next(it))