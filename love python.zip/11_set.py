s = {1,2,3,4,5,2,3}
s.add(6)
s.add(9)
print(s)