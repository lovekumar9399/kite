x = "Nütfan"
y = 21
print(x, y)