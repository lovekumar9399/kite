x = (1,2,3)
print(x)