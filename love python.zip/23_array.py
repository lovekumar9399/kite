import array
arr=array.array("i",[5,10,15,20])
print(arr[0], arr[2])