a = 2
b = "hello"
c = [1,2,3]
print(a, b, c)