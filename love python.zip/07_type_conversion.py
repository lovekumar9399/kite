x = int("1101")
y = float(5)
z = str(100)
print(x, y, z)