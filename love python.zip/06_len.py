x = "Nutan"
print(len(x))