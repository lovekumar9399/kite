num=0
if num<0:
    print("Low")
else:
    print("Good")