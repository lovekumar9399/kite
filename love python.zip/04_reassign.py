a = 2
print(a)
a = "hello"
print(a)
a = [2347]
print(a)